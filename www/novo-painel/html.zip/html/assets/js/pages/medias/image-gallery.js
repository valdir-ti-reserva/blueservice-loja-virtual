$(document).ready(function(){

    $("#lightgallery").lightGallery({
        selector: '.light-link'
    }); 
});